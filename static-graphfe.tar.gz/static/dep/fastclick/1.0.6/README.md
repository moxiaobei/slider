FastClick for EDP
===

Polyfill to remove click delays on browsers with touch UIs

Official site: https://github.com/ftlabs/fastclick
