/*! 2015 Baidu Inc. All Rights Reserved */
!function () {
    var e = { data: {} };
    e.init = e.setup = function (a, b) {
        if (typeof a === 'function') {
            a.call();
        }
    };
    window.A = e;
}();