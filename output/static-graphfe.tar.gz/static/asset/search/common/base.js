/*! 2015 Baidu Inc. All Rights Reserved */


define('search/common/js/aladdin', [
    'require',
    'common/ui/wise'
], function (require) {
    var Wise = require('common/ui/wise');
    var ic = document.getElementsByClassName('if-container');
    var nav = document.querySelector('.bdbox_wise_nav');
    var navLoading = document.querySelector('.bdbox_wise_nav--loading');
    var navContainer = document.querySelector('.bdbox_wise_nav-c');
    function wiseIframeLogic(wise, more, kw, fr) {
        if ('' + more === '1') {
            navLoading.style.display = 'block';
            nav.style.display = 'none';
            navContainer.style.display = 'block';
        }
        wise.load(kw, fr).then(function () {
            if ('' + more === '1') {
                nav.style.display = 'block';
                navLoading.style.display = 'none';
            }
        });
        if ('' + more === '1' && nav) {
            nav.addEventListener('click', function () {
                navLoading.style.display = 'block';
                nav.style.display = 'none';
                wise.more().then(function () {
                    nav.style.display = 'block';
                    navLoading.style.display = 'none';
                }).fail(function () {
                    navLoading.style.display = 'block';
                    nav.style.display = 'none';
                    navLoading.innerHTML = '\u6CA1\u6709\u66F4\u591A\u4E86';
                });
            });
        }
    }
    var exports = function () {
        for (var i = 0, n = ic.length; i < n; i++) {
            var item = ic[i];
            var kw = decodeURIComponent($(item).data('kw'));
            var fr = $(item).data('fr');
            var more = $(item).data('more');
            var w = new Wise(item, {
                fr: fr,
                domain: document.domain,
                convert: true,
                port: window.location.port
            });
            wiseIframeLogic(w, more, kw, fr);
        }
    };
    return exports;
});

define('common/widget/in-view', [
    'require',
    'common/lib/animationFrame',
    'zepto'
], function (require) {
    var selector = '[data-in-view]';
    var raf = require('common/lib/animationFrame').requestAnimationFrame;
    var $ = require('zepto');
    var statStep = 1000;
    var exports = function () {
        var lastTime = 0;
        raf(function (time) {
            lastTime = time;
            requestNextLog(time);
        });
        function requestNextLog(time) {
            if (time - lastTime > statStep) {
                lastTime = time;
                var inV = document.querySelectorAll(selector);
                if (inV.length > 0) {
                    var nl = checkInView(inV);
                    var ll = collectStInfo(nl);
                    sendLog(ll);
                }
            }
            raf(requestNextLog);
        }
        function checkInView(nodeList) {
            var inViewList = [];
            var h = window.innerHeight;
            for (var i = 0, n = nodeList.length; i < n; i++) {
                var el = nodeList[i];
                if (el.getBoundingClientRect) {
                    var rect = el.getBoundingClientRect();
                    if (rect.top >= 0 && rect.top < h) {
                        inViewList.push(el);
                    } else if (inViewList.length > 0) {
                        break;
                    }
                }
            }
            return inViewList;
        }
        function collectStInfo(nodeList) {
            var logList = [];
            for (var i = 0, n = nodeList.length; i < n; i++) {
                var el = nodeList[i];
                var s = $(el).attr('data-in-view');
                el.removeAttribute('data-in-view');
                if (s) {
                    logList.push(s);
                }
            }
            return logList;
        }
        function sendLog(logList) {
            if (logList.length === 0) {
                return;
            }
            var img = document.createElement('img');
            var path = '/api/log/?';
            path += 'a=inview';
            path += '&i=' + encodeURIComponent(logList.join('|'));
            img.src = path;
        }
    };
    return exports;
});

define('search/common/base', [
    'require',
    'exports',
    'common/widget/in-view',
    'common/lib/invoker'
], function (require, exports) {
    var inviewStatic = require('common/widget/in-view');
    var invoker = require('common/lib/invoker');
    exports.init = function () {
        inviewStatic();
        invoker.initSetQuery();
    };
    return exports;
});