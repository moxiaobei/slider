/*! 2015 Baidu Inc. All Rights Reserved */
define('scards/c_similar/pages/index', [
    'require',
    'common/widget/toast/toast',
    'common/lib/env',
    './js/slider',
    'common/widget/feedback/feedback',
    'zepto',
    'common/data'
], function (require) {
    var toast = require('common/widget/toast/toast');
    var env = require('common/lib/env');
    var slider = require('./js/slider');
    var feedback = require('common/widget/feedback/feedback');
    var $ = require('zepto');
    var exports = {};
    var data = require('common/data');
    exports.start = function () {
        var s = new slider();
        s.init({
            imgsInfo: data.imgsInfo,
            idName: 'sugguestion-waterfall'
        });
        $('.recognition').on('click', function () {
            window.top.location.href = $(this).attr('href');
            return false;
        });
        $('.slider-list').on('click', 'img', function (e) {
        });
        $('.download').on('click', function () {
            if (env.os.ios) {
            } else {
                toast.makeText('\u8BF7\u957F\u6309\u56FE\u7247\u4FDD\u5B58');
            }
            return false;
        });
        feedback.init();
    };
    return exports;
});