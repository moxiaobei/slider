/*! 2015 Baidu Inc. All Rights Reserved */
define('scards/c_similar/pages/index', [
    'require',
    'common/widget/toast/toast',
    'common/lib/env',
    './js/slider',
    'zepto',
    'common/data'
], function (require) {
    var toast = require('common/widget/toast/toast');
    var env = require('common/lib/env');
    var slider = require('./js/slider');
    var $ = require('zepto');
    var exports = {};
    var data = require('common/data');
    exports.start = function () {
        var s = new slider();
        s.init({
            imgsInfo: data.imgsInfo,
            idName: 'sugguestion-waterfall'
        });
        $('.recognition').on('click', function () {
            window.top.location.href = $(this).attr('href');
            return false;
        });
        $('.download').on('click', function () {
            if (env.os.ios) {
                var doc = window.top.document;
                var html = [
                        '<div class="imgsave-container">',
                        '  <div  class="tip">\u8BF7\u957F\u6309\u56FE\u7247\u4FDD\u5B58</div>',
                        '  <div class="img-wrap">',
                        '  <img src="' + $(this).attr('href') + '">',
                        '  </div>',
                        '</div>'
                    ].join('');
                $(doc).find('body').append(html);
                $(doc).find('.imgsave-container').one('click', function () {
                    $(doc).find('.imgsave-container').css('display', 'none');
                    $(doc).find('.imgsave-container').remove();
                });
            } else {
                toast.makeText('\u8BF7\u957F\u6309\u56FE\u7247\u4FDD\u5B58');
            }
            return false;
        });
    };
    return exports;
});