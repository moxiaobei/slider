/*! 2015 Baidu Inc. All Rights Reserved */
define('scards/c_similar/pages/index', [
    'require',
    'common/widget/Waterfall',
    './js/slider',
    'zepto',
    'common/data'
], function (require) {
    var waterfall = require('common/widget/Waterfall');
    var slider = require('./js/slider');
    var $ = require('zepto');
    var exports = {};
    var data = require('common/data');
    exports.start = function () {
        var s = new slider();
        s.init({
            imgsInfo: data.imgsInfo,
            idName: 'sugguestion-waterfall'
        });
    };
    return exports;
});