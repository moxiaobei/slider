/*! 2015 Baidu Inc. All Rights Reserved */
define('scards/c_similar/pages/index', [
    'require',
    'common/widget/Waterfall',
    'common/widget/toast/toast',
    './js/slider',
    'zepto',
    'common/data'
], function (require) {
    var waterfall = require('common/widget/Waterfall');
    var toast = require('common/widget/toast/toast');
    var slider = require('./js/slider');
    var $ = require('zepto');
    var exports = {};
    var data = require('common/data');
    exports.start = function () {
        var s = new slider();
        s.init({
            imgsInfo: data.imgsInfo,
            idName: 'sugguestion-waterfall'
        });
        $('.recognition').on('click', function () {
            window.top.location.href = $(this).attr('href');
            return false;
        });
        $('.download').on('click', function () {
            toast.makeText('\u8BF7\u957F\u6309\u56FE\u7247\u4FDD\u5B58');
            return false;
        });
    };
    return exports;
});