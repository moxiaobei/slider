/*! 2015 Baidu Inc. All Rights Reserved */
define('scards/c_similar/pages/index', [
    'require',
    'common/widget/toast/toast',
    'common/lib/env',
    './js/slider',
    'common/widget/feedback/feedback',
    'zepto',
    'common/data'
], function (require) {
    var toast = require('common/widget/toast/toast');
    var env = require('common/lib/env');
    var slider = require('./js/slider');
    var feedback = require('common/widget/feedback/feedback');
    var $ = require('zepto');
    var exports = {};
    var data = require('common/data');
    exports.start = function () {
        var s = new slider();
        s.init({
            imgsInfo: data.imgsInfo,
            idName: 'sugguestion-waterfall'
        });
        $('.recognition').on('click', function () {
            window.top.location.href = $(this).attr('href');
            return false;
        });
        $('.slider-list').on('click', 'img', function (e) {
            var $img = $(e.currentTarget);
            var doc = window.top.document;
            var html = [
                    '<div class="imgpreview-container">',
                    '  <div class="img-wrap">',
                    '  <img src="' + $img.attr('src') + '">',
                    '  </div>',
                    '</div>'
                ].join('');
            $(doc).find('body').append(html);
            $preview = $(doc).find('.imgpreview-container');
            $preview.css('line-height', $(window.top).height() + 'px');
            $preview.one('click', function () {
                $preview.css('display', 'none');
                $preview.remove();
            });
            return false;
        });
        $('.download').on('click', function () {
            if (env.os.ios) {
            } else {
                toast.makeText('\u8BF7\u957F\u6309\u56FE\u7247\u4FDD\u5B58');
            }
            return false;
        });
        feedback.init();
    };
    return exports;
});