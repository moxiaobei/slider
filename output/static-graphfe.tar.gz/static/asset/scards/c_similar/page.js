/*! 2015 Baidu Inc. All Rights Reserved */
require(['common/widget/Waterfall'], function (waterfall) {
    var wf = new waterfall();
    wf.init({
        idName: 'waterfall',
        ajaxUrl: simAjaxUrl,
        containerId: 'viewport'
    });
    wf.getImages();
});
require([
    'common/widget/backtop/backtop',
    'zepto'
], function (backtop, $) {
    backtop.init({ ele: 'backtop' });
    $(window).on('scroll', function () {
        if ($(window).scrollTop() > 100) {
            backtop.show();
        } else {
            backtop.hide();
        }
    });
});