/*! 2015 Baidu Inc. All Rights Reserved */
require(['common/widget/Waterfall'], function (waterfall) {
    var wf = new waterfall();
    wf.init({
        idName: 'waterfall',
        ajaxUrl: simAjaxUrl,
        containerId: 'viewport'
    });
    wf.getImages();
});
require([
    'common/widget/backtop/backtop',
    'zepto'
], function (backtop, $) {
    $(document.body).append('<div id="backtop"></div>');
    $(window).on('scroll', function () {
        if ($(window).scrollTop() > 0) {
            backtop.show();
        } else {
            backtop.hide();
        }
        $('#backtop').on('click', function () {
            $(window).scrollTop(0);
        });
    });
});