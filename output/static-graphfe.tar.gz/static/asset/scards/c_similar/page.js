/*! 2015 Baidu Inc. All Rights Reserved */
require(["common/widget/Waterfall"],function(e){var t=new e;t.init({idName:"waterfall",ajaxUrl:simAjaxUrl,containerId:"viewport"}),t.getImages()});