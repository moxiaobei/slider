/*! 2015 Baidu Inc. All Rights Reserved */
require(['common/widget/Waterfall'], function (waterfall) {
    var wf = new waterfall();
    wf.init({
        idName: 'waterfall',
        ajaxUrl: simAjaxUrl,
        containerId: 'viewport'
    });
    wf.getImages();
});