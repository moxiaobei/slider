/*! 2015 Baidu Inc. All Rights Reserved */
require([
    'zepto',
    'common/lib/invoker',
    'common/widget/attatch'
], function ($, invoker, Attatch) {
    invoker.initCallEditor();
    var $card = $('#c-invoke-edit').closest('.result');
    var attatch = new Attatch({ main: $card });
    $card.find('.close').on('click', function () {
        $card.hide();
        attatch.dispose();
        attatch = null;
        return false;
    });
});