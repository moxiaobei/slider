/*! 2015 Baidu Inc. All Rights Reserved */
require([
    'zepto',
    'common/lib/env'
], function ($, env) {
    var $card = $('#c-download-tip').closest('.result');
    function openApp() {
        if (env.os.ios) {
            var url = 'http://m.baidu.com/searchbox?action=reserve&type=baiduchannel&from=1000715p';
            var iframe = $('<iframe>').hide().attr('src', url).appendTo('body');
            setTimeout(function () {
                iframe.remove();
            }, 3000);
        } else {
            location.href = 'http://dl.ops.baidu.com/baidusearch_AndroidPhone_1006979s.apk';
        }
    }
    $card.on('click', function () {
        openApp();
    });
    $card.find('.close').on('click', function () {
        $card.hide();
        return false;
    });
});