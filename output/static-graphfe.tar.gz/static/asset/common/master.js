/*! 2015 Baidu Inc. All Rights Reserved */
define("common/master",["require"],function(){function e(){}var exports={};return exports.start=function(){e()},exports});