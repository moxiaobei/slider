/*! 2015 Baidu Inc. All Rights Reserved */
define('common/lib/animationFrame', ['require'], function (require) {
    var lastTime = 0;
    var requestAnimationFrame;
    var cancelAnimationFrame;
    var vendors = [
            'ms',
            'moz',
            'webkit',
            'o'
        ];
    for (var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
        requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
        cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] || window[vendors[x] + 'CancelRequestAnimationFrame'];
    }
    if (!requestAnimationFrame) {
        requestAnimationFrame = function (callback) {
            var currTime = new Date().getTime();
            var timeToCall = Math.max(0, 16 - (currTime - lastTime));
            var id = window.setTimeout(function () {
                    callback(currTime + timeToCall);
                }, timeToCall);
            lastTime = currTime + timeToCall;
            return id;
        };
    }
    if (!cancelAnimationFrame) {
        cancelAnimationFrame = function (id) {
            clearTimeout(id);
        };
    }
    return {
        requestAnimationFrame: requestAnimationFrame,
        cancelAnimationFrame: cancelAnimationFrame
    };
});

define('common/lib/env', ['require'], function (require) {
    var ua = navigator.userAgent;
    var os = {};
    var browser = {};
    var webkit = ua.match(/Web[kK]it[\/]{0,1}([\d.]+)/);
    var android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
    var ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
    var ipod = ua.match(/(iPod)(.*OS\s([\d_]+))?/);
    var iphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/);
    var webos = ua.match(/(webOS|hpwOS)[\s\/]([\d.]+)/);
    var touchpad = webos && ua.match(/TouchPad/);
    var kindle = ua.match(/Kindle\/([\d.]+)/);
    var silk = ua.match(/Silk\/([\d._]+)/);
    var blackberry = ua.match(/(BlackBerry).*Version\/([\d.]+)/);
    var bb10 = ua.match(/(BB10).*Version\/([\d.]+)/);
    var rimtabletos = ua.match(/(RIM\sTablet\sOS)\s([\d.]+)/);
    var playbook = ua.match(/PlayBook/);
    var chrome = ua.match(/Chrome\/([\d.]+)/) || ua.match(/CriOS\/([\d.]+)/);
    var firefox = ua.match(/Firefox\/([\d.]+)/);
    var ie = ua.match(/MSIE ([\d.]+)/) || ua.match(/MSIE\s([\d.]+)/);
    var webview = ua.match(/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/) && !chrome;
    var runtime = ua.match(/BaiduLightAppRuntime/i);
    var qingpai = ua.match(/qingpai(ios|android)client/i);
    var uc = ua.match(/UCBrowser[\/]?([\d.]+)/i);
    var weixin = ua.match(/MicroMessenger/i);
    var weibo = ua.match(/Weibo/i);
    var qq = ua.match(/MQQ/i);
    var hao123 = ua.match(/hao123\/([\d.]+)/i);
    var safari = webkit && ua.match(/Mobile\//) && !chrome && !uc && !weixin && !qq && !weibo && !hao123;
    if (browser.webkit = !!webkit) {
        browser.version = webkit[1];
    }
    if (android) {
        os.android = true;
        os.version = android[2];
    }
    if (iphone && !ipod) {
        os.ios = os.iphone = true;
        os.version = iphone[2].replace(/_/g, '.');
    }
    if (ipad) {
        os.ios = os.ipad = true;
        os.version = ipad[2].replace(/_/g, '.');
    }
    if (ipod) {
        os.ios = os.ipod = true;
        os.version = ipod[3] ? ipod[3].replace(/_/g, '.') : null;
    }
    if (webos) {
        os.webos = true;
        os.version = webos[2];
    }
    if (touchpad) {
        os.touchpad = true;
    }
    if (blackberry) {
        os.blackberry = true;
        os.version = blackberry[2];
    }
    if (bb10) {
        os.bb10 = true;
        os.version = bb10[2];
    }
    if (rimtabletos) {
        os.rimtabletos = true;
        os.version = rimtabletos[2];
    }
    if (playbook) {
        browser.playbook = true;
    }
    if (kindle) {
        os.kindle = true;
        os.version = kindle[1];
    }
    if (silk) {
        browser.silk = true;
        browser.version = silk[1];
    }
    if (!silk && os.android && ua.match(/Kindle Fire/)) {
        browser.silk = true;
    }
    if (chrome) {
        browser.chrome = true;
        browser.version = chrome[1];
    }
    if (firefox) {
        browser.firefox = true;
        browser.version = firefox[1];
    }
    if (ie) {
        browser.ie = true;
        browser.version = ie[1];
    }
    if (safari && (ua.match(/Safari/) || !!os.ios)) {
        browser.safari = true;
    }
    if (webview) {
        browser.webview = true;
    }
    if (ie) {
        browser.ie = true;
        browser.version = ie[1];
    }
    if (runtime) {
        browser.runtime = true;
    }
    if (uc) {
        browser.uc = true;
        browser.version = uc[1];
    }
    if (qq) {
        browser.qq = true;
    }
    if (weixin) {
        browser.weixin = true;
    }
    if (weibo) {
        browser.weibo = true;
    }
    if (qingpai) {
        browser.runtime = true;
        browser.qingpai = true;
    }
    os.tablet = !!(ipad || playbook || android && !ua.match(/Mobile/) || firefox && ua.match(/Tablet/) || ie && !ua.match(/Phone/) && ua.match(/Touch/));
    os.phone = !!(!os.tablet && !os.ipod && (android || iphone || webos || blackberry || bb10 || chrome && ua.match(/Android/) || chrome && ua.match(/CriOS\/([\d.]+)/) || firefox && ua.match(/Mobile/) || ie && ua.match(/Touch/)));
    var ret = {
            os: os,
            browser: browser
        };
    var isReady = false;
    var readyList = [];
    function ready(fn) {
        if (isReady) {
            setTimeout(function () {
                fn();
            }, 0);
            return;
        }
        readyList.push(fn);
    }
    function setReady() {
        if (isReady) {
            return;
        }
        isReady = true;
        for (var i = 0, n = readyList.length; i < n; i++) {
            readyList[i]();
        }
        readyList.length = 0;
    }
    (function () {
        if (document.readyState === 'complete') {
            setTimeout(setReady, 0);
        } else {
            document.addEventListener('DOMContentLoaded', setReady);
            window.addEventListener('load', setReady);
        }
    }());
    ret.ready = ready;
    ret.guid = function (prefix) {
        prefix = prefix || '';
        return prefix + setTimeout(function () {
        }, 0);
    };
    ret.uuid = function () {
        var cs = document.cookie.split(';');
        var parseCookie = {};
        for (var i = 0, n = cs.length; i < n; i++) {
            var t = cs[i].split('=');
            parseCookie[t[0].replace(/\s+/g, '')] = t[1];
        }
        return parseCookie.reqid || new Date().getTime() + (ret.os.ios ? '01' : ret.os.android ? '02' : '00');
    }();
    ret.getAk = function (urlencoding) {
        var r = ret.browser.runtime ? 'eyJjdCI6IjIwIn0=' : 'eyJjdCI6IjEwIn0=';
        if (urlencoding) {
            r = encodeURIComponent(r);
        }
        return r;
    };
    return ret;
});

define('common/lib/invoker', [
    'require',
    'exports',
    'zepto',
    'common/lib/env',
    'openjs'
], function (require, exports) {
    var $ = require('zepto');
    var env = require('common/lib/env');
    var Box = require('openjs');
    var imgKey = function () {
            var r = /([iI][rR]|[gG][dD]|[eE][sS])-(\w{8}-\w{4}-\w{4}-\w{4}-\w{12})/;
            var result = location.pathname.match(r);
            if (result) {
                result = result[0];
            } else {
                result = null;
            }
            return function () {
                return result;
            };
        }();
    var callEditor = function () {
            var imageSearchType = $('#imageSearchType').val() || 'GENERAL';
            var data = {};
            var refUrl = encodeURIComponent(window.location.href);
            if (window._t_url) {
                data.key = null;
                data.url = window._t_url;
            } else {
                data.key = imgKey();
                data.url = null;
            }
            if (env.os.ios) {
                return function () {
                    env.ready(function () {
                        data.referrer = 'http://qingpai.baidu.com/';
                        var refUrl = window.location.href;
                        Box.ios.invokeApp('imagesearch', {
                            action: 'editimage',
                            args: encodeURIComponent('' + 'source_app=BROWSER&referer=' + refUrl + '&imageSearch_type=' + imageSearchType),
                            params: encodeURIComponent(JSON.stringify(data)),
                            minver: encodeURIComponent('5.5.0.0')
                        });
                    });
                };
            }
            if (env.os.android) {
                return function () {
                    env.ready(function () {
                        data.imageSearch_type = imageSearchType;
                        data.source_app = 'BROWSER';
                        data.referer = refUrl;
                        Box.android.invokeApp('Bdbox_android_imagesearch', 'editImage', [JSON.stringify(data)]);
                    });
                };
            }
            return function () {
                alert('\u6682\u65F6\u4E0D\u652F\u6301\u975E Android\uFF0CiOS \u5E73\u53F0');
            };
        }();
    var callImageSearch = function () {
            var imageSearchType = $('#imageSearchType').val() || 'GENERAL';
            var data = {};
            var refUrl = encodeURIComponent(window.location.href);
            if (window._t_url) {
                data.key = null;
                data.url = window._t_url;
            } else {
                data.key = imgKey();
                data.url = null;
            }
            if (env.os.ios) {
                return function () {
                    env.ready(function () {
                        data.referrer = 'http://qingpai.baidu.com/';
                        var refUrl = window.location.href;
                        Box.ios.invokeApp('imagesearch', {
                            action: 'imagesearch',
                            params: encodeURIComponent(JSON.stringify(data)),
                            args: encodeURIComponent('' + 'source_app=BROWSER&referer=' + refUrl + '&imageSearch_type=' + imageSearchType),
                            minver: encodeURIComponent('3.8.0.0')
                        });
                    });
                };
            }
            if (env.os.android) {
                return function () {
                    env.ready(function () {
                        Box.android.invokeApp('Bdbox_android_send_intent', 'send', ['intent:widgetid://com.baidu.searchbox/-1#Intent;' + 'action=com.baidu.searchbox.action.MAIN;' + 'category=android.intent.category.LAUNCHER;' + 'component=com.baidu.searchbox/.CodeScannerActivity;' + 'launchFlags=0x10000000;' + 'S.from=7;' + 'S.source_app=BROWSER;' + 'S.referer=' + refUrl + ';' + 'S.imageSearch_type=' + imageSearchType + ';' + 'end']);
                    });
                };
            }
            return function () {
                alert('\u6682\u65F6\u4E0D\u652F\u6301\u975E Android\uFF0CiOS \u5E73\u53F0');
            };
        }();
    exports.initCallEditor = function (ele) {
        ele = ele || '.c-invoke-edit-btn';
        var $editBtn = $(ele);
        $editBtn.on('click', function (e) {
            e.preventDefault();
            callEditor();
        });
    };
    exports.initCallImageSearch = function (ele) {
        ele = ele || '.c-invoke-image-search';
        var searchBtn = document.querySelector(ele);
        if (searchBtn) {
            searchBtn.addEventListener('click', function (ev) {
                ev.preventDefault();
                callImageSearch();
            });
        }
    };
    exports.initSetQuery = function () {
        window.addEventListener('pageshow', function () {
            env.ready(function () {
                if (env.os.ios) {
                    Box.ios.invokeApp('setquery', {
                        params: encodeURIComponent(JSON.stringify({
                            type: 'image',
                            query: window._t_base64
                        })),
                        minver: encodeURIComponent('5.5.0.0')
                    });
                }
                if (env.os.android) {
                    Box.android.invokeApp('Bdbox_android_common', 'setQuery', [JSON.stringify({
                            type: 'image',
                            query: window._t_base64
                        })]);
                }
            });
        }, true);
    };
    return exports;
});

define('common/lib/q', ['require'], function (require) {
    'use strict';
    var hasStacks = false;
    try {
        throw new Error();
    } catch (e) {
        hasStacks = !!e.stack;
    }
    var qStartingLine = captureLine();
    var qFileName;
    var noop = function () {
    };
    var nextTick = function () {
            var head = {
                    task: void 0,
                    next: null
                };
            var tail = head;
            var flushing = false;
            var requestTick = void 0;
            var isNodeJS = false;
            function flush() {
                while (head.next) {
                    head = head.next;
                    var task = head.task;
                    head.task = void 0;
                    var domain = head.domain;
                    if (domain) {
                        head.domain = void 0;
                        domain.enter();
                    }
                    try {
                        task();
                    } catch (e) {
                        if (isNodeJS) {
                            if (domain) {
                                domain.exit();
                            }
                            setTimeout(flush, 0);
                            if (domain) {
                                domain.enter();
                            }
                            throw e;
                        } else {
                            setTimeout(function () {
                                throw e;
                            }, 0);
                        }
                    }
                    if (domain) {
                        domain.exit();
                    }
                }
                flushing = false;
            }
            nextTick = function (task) {
                tail = tail.next = {
                    task: task,
                    domain: isNodeJS && process.domain,
                    next: null
                };
                if (!flushing) {
                    flushing = true;
                    requestTick();
                }
            };
            if (typeof process !== 'undefined' && process.nextTick) {
                isNodeJS = true;
                requestTick = function () {
                    process.nextTick(flush);
                };
            } else if (typeof setImmediate === 'function') {
                if (typeof window !== 'undefined') {
                    requestTick = setImmediate.bind(window, flush);
                } else {
                    requestTick = function () {
                        setImmediate(flush);
                    };
                }
            } else if (typeof MessageChannel !== 'undefined') {
                var channel = new MessageChannel();
                channel.port1.onmessage = function () {
                    requestTick = requestPortTick;
                    channel.port1.onmessage = flush;
                    flush();
                };
                var requestPortTick = function () {
                    channel.port2.postMessage(0);
                };
                requestTick = function () {
                    setTimeout(flush, 0);
                    requestPortTick();
                };
            } else {
                requestTick = function () {
                    setTimeout(flush, 0);
                };
            }
            return nextTick;
        }();
    var call = Function.call;
    function uncurryThis(f) {
        return function () {
            return call.apply(f, arguments);
        };
    }
    var array_slice = uncurryThis(Array.prototype.slice);
    var array_reduce = uncurryThis(Array.prototype.reduce || function (callback, basis) {
            var index = 0, length = this.length;
            if (arguments.length === 1) {
                do {
                    if (index in this) {
                        basis = this[index++];
                        break;
                    }
                    if (++index >= length) {
                        throw new TypeError();
                    }
                } while (1);
            }
            for (; index < length; index++) {
                if (index in this) {
                    basis = callback(basis, this[index], index);
                }
            }
            return basis;
        });
    var array_indexOf = uncurryThis(Array.prototype.indexOf || function (value) {
            for (var i = 0; i < this.length; i++) {
                if (this[i] === value) {
                    return i;
                }
            }
            return -1;
        });
    var array_map = uncurryThis(Array.prototype.map || function (callback, thisp) {
            var self = this;
            var collect = [];
            array_reduce(self, function (undefined, value, index) {
                collect.push(callback.call(thisp, value, index, self));
            }, void 0);
            return collect;
        });
    var object_create = Object.create || function (prototype) {
            function Type() {
            }
            Type.prototype = prototype;
            return new Type();
        };
    var object_hasOwnProperty = uncurryThis(Object.prototype.hasOwnProperty);
    var object_keys = Object.keys || function (object) {
            var keys = [];
            for (var key in object) {
                if (object_hasOwnProperty(object, key)) {
                    keys.push(key);
                }
            }
            return keys;
        };
    var object_toString = uncurryThis(Object.prototype.toString);
    function isObject(value) {
        return value === Object(value);
    }
    function isStopIteration(exception) {
        return object_toString(exception) === '[object StopIteration]' || exception instanceof QReturnValue;
    }
    var QReturnValue;
    if (typeof ReturnValue !== 'undefined') {
        QReturnValue = ReturnValue;
    } else {
        QReturnValue = function (value) {
            this.value = value;
        };
    }
    var STACK_JUMP_SEPARATOR = 'From previous event:';
    function makeStackTraceLong(error, promise) {
        if (hasStacks && promise.stack && typeof error === 'object' && error !== null && error.stack && error.stack.indexOf(STACK_JUMP_SEPARATOR) === -1) {
            var stacks = [];
            for (var p = promise; !!p; p = p.source) {
                if (p.stack) {
                    stacks.unshift(p.stack);
                }
            }
            stacks.unshift(error.stack);
            var concatedStacks = stacks.join('\n' + STACK_JUMP_SEPARATOR + '\n');
            error.stack = filterStackString(concatedStacks);
        }
    }
    function filterStackString(stackString) {
        var lines = stackString.split('\n');
        var desiredLines = [];
        for (var i = 0; i < lines.length; ++i) {
            var line = lines[i];
            if (!isInternalFrame(line) && !isNodeFrame(line) && line) {
                desiredLines.push(line);
            }
        }
        return desiredLines.join('\n');
    }
    function isNodeFrame(stackLine) {
        return stackLine.indexOf('(module.js:') !== -1 || stackLine.indexOf('(node.js:') !== -1;
    }
    function getFileNameAndLineNumber(stackLine) {
        var attempt1 = /at .+ \((.+):(\d+):(?:\d+)\)$/.exec(stackLine);
        if (attempt1) {
            return [
                attempt1[1],
                Number(attempt1[2])
            ];
        }
        var attempt2 = /at ([^ ]+):(\d+):(?:\d+)$/.exec(stackLine);
        if (attempt2) {
            return [
                attempt2[1],
                Number(attempt2[2])
            ];
        }
        var attempt3 = /.*@(.+):(\d+)$/.exec(stackLine);
        if (attempt3) {
            return [
                attempt3[1],
                Number(attempt3[2])
            ];
        }
    }
    function isInternalFrame(stackLine) {
        var fileNameAndLineNumber = getFileNameAndLineNumber(stackLine);
        if (!fileNameAndLineNumber) {
            return false;
        }
        var fileName = fileNameAndLineNumber[0];
        var lineNumber = fileNameAndLineNumber[1];
        return fileName === qFileName && lineNumber >= qStartingLine && lineNumber <= qEndingLine;
    }
    function captureLine() {
        if (!hasStacks) {
            return;
        }
        try {
            throw new Error();
        } catch (e) {
            var lines = e.stack.split('\n');
            var firstLine = lines[0].indexOf('@') > 0 ? lines[1] : lines[2];
            var fileNameAndLineNumber = getFileNameAndLineNumber(firstLine);
            if (!fileNameAndLineNumber) {
                return;
            }
            qFileName = fileNameAndLineNumber[0];
            return fileNameAndLineNumber[1];
        }
    }
    function deprecate(callback, name, alternative) {
        return function () {
            if (typeof console !== 'undefined' && typeof console.warn === 'function') {
                console.warn(name + ' is deprecated, use ' + alternative + ' instead.', new Error('').stack);
            }
            return callback.apply(callback, arguments);
        };
    }
    function Q(value) {
        if (isPromise(value)) {
            return value;
        }
        if (isPromiseAlike(value)) {
            return coerce(value);
        } else {
            return fulfill(value);
        }
    }
    Q.resolve = Q;
    Q.nextTick = nextTick;
    Q.longStackSupport = false;
    Q.defer = defer;
    function defer() {
        var messages = [], progressListeners = [], resolvedPromise;
        var deferred = object_create(defer.prototype);
        var promise = object_create(Promise.prototype);
        promise.promiseDispatch = function (resolve, op, operands) {
            var args = array_slice(arguments);
            if (messages) {
                messages.push(args);
                if (op === 'when' && operands[1]) {
                    progressListeners.push(operands[1]);
                }
            } else {
                nextTick(function () {
                    resolvedPromise.promiseDispatch.apply(resolvedPromise, args);
                });
            }
        };
        promise.valueOf = function () {
            if (messages) {
                return promise;
            }
            var nearerValue = nearer(resolvedPromise);
            if (isPromise(nearerValue)) {
                resolvedPromise = nearerValue;
            }
            return nearerValue;
        };
        promise.inspect = function () {
            if (!resolvedPromise) {
                return { state: 'pending' };
            }
            return resolvedPromise.inspect();
        };
        if (Q.longStackSupport && hasStacks) {
            try {
                throw new Error();
            } catch (e) {
                promise.stack = e.stack.substring(e.stack.indexOf('\n') + 1);
            }
        }
        function become(newPromise) {
            resolvedPromise = newPromise;
            promise.source = newPromise;
            array_reduce(messages, function (undefined, message) {
                nextTick(function () {
                    newPromise.promiseDispatch.apply(newPromise, message);
                });
            }, void 0);
            messages = void 0;
            progressListeners = void 0;
        }
        deferred.promise = promise;
        deferred.resolve = function (value) {
            if (resolvedPromise) {
                return;
            }
            become(Q(value));
        };
        deferred.fulfill = function (value) {
            if (resolvedPromise) {
                return;
            }
            become(fulfill(value));
        };
        deferred.reject = function (reason) {
            if (resolvedPromise) {
                return;
            }
            become(reject(reason));
        };
        deferred.notify = function (progress) {
            if (resolvedPromise) {
                return;
            }
            array_reduce(progressListeners, function (undefined, progressListener) {
                nextTick(function () {
                    progressListener(progress);
                });
            }, void 0);
        };
        return deferred;
    }
    defer.prototype.makeNodeResolver = function () {
        var self = this;
        return function (error, value) {
            if (error) {
                self.reject(error);
            } else if (arguments.length > 2) {
                self.resolve(array_slice(arguments, 1));
            } else {
                self.resolve(value);
            }
        };
    };
    Q.Promise = promise;
    Q.promise = promise;
    function promise(resolver) {
        if (typeof resolver !== 'function') {
            throw new TypeError('resolver must be a function.');
        }
        var deferred = defer();
        try {
            resolver(deferred.resolve, deferred.reject, deferred.notify);
        } catch (reason) {
            deferred.reject(reason);
        }
        return deferred.promise;
    }
    promise.race = race;
    promise.all = all;
    promise.reject = reject;
    promise.resolve = Q;
    Q.passByCopy = function (object) {
        return object;
    };
    Promise.prototype.passByCopy = function () {
        return this;
    };
    Q.join = function (x, y) {
        return Q(x).join(y);
    };
    Promise.prototype.join = function (that) {
        return Q([
            this,
            that
        ]).spread(function (x, y) {
            if (x === y) {
                return x;
            } else {
                throw new Error('Can\'t join: not the same: ' + x + ' ' + y);
            }
        });
    };
    Q.race = race;
    function race(answerPs) {
        return promise(function (resolve, reject) {
            for (var i = 0, len = answerPs.length; i < len; i++) {
                Q(answerPs[i]).then(resolve, reject);
            }
        });
    }
    Promise.prototype.race = function () {
        return this.then(Q.race);
    };
    Q.makePromise = Promise;
    function Promise(descriptor, fallback, inspect) {
        if (fallback === void 0) {
            fallback = function (op) {
                return reject(new Error('Promise does not support operation: ' + op));
            };
        }
        if (inspect === void 0) {
            inspect = function () {
                return { state: 'unknown' };
            };
        }
        var promise = object_create(Promise.prototype);
        promise.promiseDispatch = function (resolve, op, args) {
            var result;
            try {
                if (descriptor[op]) {
                    result = descriptor[op].apply(promise, args);
                } else {
                    result = fallback.call(promise, op, args);
                }
            } catch (exception) {
                result = reject(exception);
            }
            if (resolve) {
                resolve(result);
            }
        };
        promise.inspect = inspect;
        if (inspect) {
            var inspected = inspect();
            if (inspected.state === 'rejected') {
                promise.exception = inspected.reason;
            }
            promise.valueOf = function () {
                var inspected = inspect();
                if (inspected.state === 'pending' || inspected.state === 'rejected') {
                    return promise;
                }
                return inspected.value;
            };
        }
        return promise;
    }
    Promise.prototype.toString = function () {
        return '[object Promise]';
    };
    Promise.prototype.then = function (fulfilled, rejected, progressed) {
        var self = this;
        var deferred = defer();
        var done = false;
        function _fulfilled(value) {
            try {
                return typeof fulfilled === 'function' ? fulfilled(value) : value;
            } catch (exception) {
                return reject(exception);
            }
        }
        function _rejected(exception) {
            if (typeof rejected === 'function') {
                makeStackTraceLong(exception, self);
                try {
                    return rejected(exception);
                } catch (newException) {
                    return reject(newException);
                }
            }
            return reject(exception);
        }
        function _progressed(value) {
            return typeof progressed === 'function' ? progressed(value) : value;
        }
        nextTick(function () {
            self.promiseDispatch(function (value) {
                if (done) {
                    return;
                }
                done = true;
                deferred.resolve(_fulfilled(value));
            }, 'when', [function (exception) {
                    if (done) {
                        return;
                    }
                    done = true;
                    deferred.resolve(_rejected(exception));
                }]);
        });
        self.promiseDispatch(void 0, 'when', [
            void 0,
            function (value) {
                var newValue;
                var threw = false;
                try {
                    newValue = _progressed(value);
                } catch (e) {
                    threw = true;
                    if (Q.onerror) {
                        Q.onerror(e);
                    } else {
                        throw e;
                    }
                }
                if (!threw) {
                    deferred.notify(newValue);
                }
            }
        ]);
        return deferred.promise;
    };
    Q.when = when;
    function when(value, fulfilled, rejected, progressed) {
        return Q(value).then(fulfilled, rejected, progressed);
    }
    Promise.prototype.thenResolve = function (value) {
        return this.then(function () {
            return value;
        });
    };
    Q.thenResolve = function (promise, value) {
        return Q(promise).thenResolve(value);
    };
    Promise.prototype.thenReject = function (reason) {
        return this.then(function () {
            throw reason;
        });
    };
    Q.thenReject = function (promise, reason) {
        return Q(promise).thenReject(reason);
    };
    Q.nearer = nearer;
    function nearer(value) {
        if (isPromise(value)) {
            var inspected = value.inspect();
            if (inspected.state === 'fulfilled') {
                return inspected.value;
            }
        }
        return value;
    }
    Q.isPromise = isPromise;
    function isPromise(object) {
        return isObject(object) && typeof object.promiseDispatch === 'function' && typeof object.inspect === 'function';
    }
    Q.isPromiseAlike = isPromiseAlike;
    function isPromiseAlike(object) {
        return isObject(object) && typeof object.then === 'function';
    }
    Q.isPending = isPending;
    function isPending(object) {
        return isPromise(object) && object.inspect().state === 'pending';
    }
    Promise.prototype.isPending = function () {
        return this.inspect().state === 'pending';
    };
    Q.isFulfilled = isFulfilled;
    function isFulfilled(object) {
        return !isPromise(object) || object.inspect().state === 'fulfilled';
    }
    Promise.prototype.isFulfilled = function () {
        return this.inspect().state === 'fulfilled';
    };
    Q.isRejected = isRejected;
    function isRejected(object) {
        return isPromise(object) && object.inspect().state === 'rejected';
    }
    Promise.prototype.isRejected = function () {
        return this.inspect().state === 'rejected';
    };
    var unhandledReasons = [];
    var unhandledRejections = [];
    var trackUnhandledRejections = true;
    function resetUnhandledRejections() {
        unhandledReasons.length = 0;
        unhandledRejections.length = 0;
        if (!trackUnhandledRejections) {
            trackUnhandledRejections = true;
        }
    }
    function trackRejection(promise, reason) {
        if (!trackUnhandledRejections) {
            return;
        }
        unhandledRejections.push(promise);
        if (reason && typeof reason.stack !== 'undefined') {
            unhandledReasons.push(reason.stack);
        } else {
            unhandledReasons.push('(no stack) ' + reason);
        }
    }
    function untrackRejection(promise) {
        if (!trackUnhandledRejections) {
            return;
        }
        var at = array_indexOf(unhandledRejections, promise);
        if (at !== -1) {
            unhandledRejections.splice(at, 1);
            unhandledReasons.splice(at, 1);
        }
    }
    Q.resetUnhandledRejections = resetUnhandledRejections;
    Q.getUnhandledReasons = function () {
        return unhandledReasons.slice();
    };
    Q.stopUnhandledRejectionTracking = function () {
        resetUnhandledRejections();
        trackUnhandledRejections = false;
    };
    resetUnhandledRejections();
    Q.reject = reject;
    function reject(reason) {
        var rejection = Promise({
                'when': function (rejected) {
                    if (rejected) {
                        untrackRejection(this);
                    }
                    return rejected ? rejected(reason) : this;
                }
            }, function fallback() {
                return this;
            }, function inspect() {
                return {
                    state: 'rejected',
                    reason: reason
                };
            });
        trackRejection(rejection, reason);
        return rejection;
    }
    Q.fulfill = fulfill;
    function fulfill(value) {
        return Promise({
            'when': function () {
                return value;
            },
            'get': function (name) {
                return value[name];
            },
            'set': function (name, rhs) {
                value[name] = rhs;
            },
            'delete': function (name) {
                delete value[name];
            },
            'post': function (name, args) {
                if (name === null || name === void 0) {
                    return value.apply(void 0, args);
                } else {
                    return value[name].apply(value, args);
                }
            },
            'apply': function (thisp, args) {
                return value.apply(thisp, args);
            },
            'keys': function () {
                return object_keys(value);
            }
        }, void 0, function inspect() {
            return {
                state: 'fulfilled',
                value: value
            };
        });
    }
    function coerce(promise) {
        var deferred = defer();
        nextTick(function () {
            try {
                promise.then(deferred.resolve, deferred.reject, deferred.notify);
            } catch (exception) {
                deferred.reject(exception);
            }
        });
        return deferred.promise;
    }
    Q.master = master;
    function master(object) {
        return Promise({
            'isDef': function () {
            }
        }, function fallback(op, args) {
            return dispatch(object, op, args);
        }, function () {
            return Q(object).inspect();
        });
    }
    Q.spread = spread;
    function spread(value, fulfilled, rejected) {
        return Q(value).spread(fulfilled, rejected);
    }
    Promise.prototype.spread = function (fulfilled, rejected) {
        return this.all().then(function (array) {
            return fulfilled.apply(void 0, array);
        }, rejected);
    };
    Q.async = async;
    function async(makeGenerator) {
        return function () {
            function continuer(verb, arg) {
                var result;
                if (typeof StopIteration === 'undefined') {
                    try {
                        result = generator[verb](arg);
                    } catch (exception) {
                        return reject(exception);
                    }
                    if (result.done) {
                        return result.value;
                    } else {
                        return when(result.value, callback, errback);
                    }
                } else {
                    try {
                        result = generator[verb](arg);
                    } catch (exception) {
                        if (isStopIteration(exception)) {
                            return exception.value;
                        } else {
                            return reject(exception);
                        }
                    }
                    return when(result, callback, errback);
                }
            }
            var generator = makeGenerator.apply(this, arguments);
            var callback = continuer.bind(continuer, 'next');
            var errback = continuer.bind(continuer, 'throw');
            return callback();
        };
    }
    Q.spawn = spawn;
    function spawn(makeGenerator) {
        Q.done(Q.async(makeGenerator)());
    }
    Q['return'] = _return;
    function _return(value) {
        throw new QReturnValue(value);
    }
    Q.promised = promised;
    function promised(callback) {
        return function () {
            return spread([
                this,
                all(arguments)
            ], function (self, args) {
                return callback.apply(self, args);
            });
        };
    }
    Q.dispatch = dispatch;
    function dispatch(object, op, args) {
        return Q(object).dispatch(op, args);
    }
    Promise.prototype.dispatch = function (op, args) {
        var self = this;
        var deferred = defer();
        nextTick(function () {
            self.promiseDispatch(deferred.resolve, op, args);
        });
        return deferred.promise;
    };
    Q.get = function (object, key) {
        return Q(object).dispatch('get', [key]);
    };
    Promise.prototype.get = function (key) {
        return this.dispatch('get', [key]);
    };
    Q.set = function (object, key, value) {
        return Q(object).dispatch('set', [
            key,
            value
        ]);
    };
    Promise.prototype.set = function (key, value) {
        return this.dispatch('set', [
            key,
            value
        ]);
    };
    Q.del = Q['delete'] = function (object, key) {
        return Q(object).dispatch('delete', [key]);
    };
    Promise.prototype.del = Promise.prototype['delete'] = function (key) {
        return this.dispatch('delete', [key]);
    };
    Q.mapply = Q.post = function (object, name, args) {
        return Q(object).dispatch('post', [
            name,
            args
        ]);
    };
    Promise.prototype.mapply = Promise.prototype.post = function (name, args) {
        return this.dispatch('post', [
            name,
            args
        ]);
    };
    Q.send = Q.mcall = Q.invoke = function (object, name) {
        return Q(object).dispatch('post', [
            name,
            array_slice(arguments, 2)
        ]);
    };
    Promise.prototype.send = Promise.prototype.mcall = Promise.prototype.invoke = function (name) {
        return this.dispatch('post', [
            name,
            array_slice(arguments, 1)
        ]);
    };
    Q.fapply = function (object, args) {
        return Q(object).dispatch('apply', [
            void 0,
            args
        ]);
    };
    Promise.prototype.fapply = function (args) {
        return this.dispatch('apply', [
            void 0,
            args
        ]);
    };
    Q['try'] = Q.fcall = function (object) {
        return Q(object).dispatch('apply', [
            void 0,
            array_slice(arguments, 1)
        ]);
    };
    Promise.prototype.fcall = function () {
        return this.dispatch('apply', [
            void 0,
            array_slice(arguments)
        ]);
    };
    Q.fbind = function (object) {
        var promise = Q(object);
        var args = array_slice(arguments, 1);
        return function fbound() {
            return promise.dispatch('apply', [
                this,
                args.concat(array_slice(arguments))
            ]);
        };
    };
    Promise.prototype.fbind = function () {
        var promise = this;
        var args = array_slice(arguments);
        return function fbound() {
            return promise.dispatch('apply', [
                this,
                args.concat(array_slice(arguments))
            ]);
        };
    };
    Q.keys = function (object) {
        return Q(object).dispatch('keys', []);
    };
    Promise.prototype.keys = function () {
        return this.dispatch('keys', []);
    };
    Q.all = all;
    function all(promises) {
        return when(promises, function (promises) {
            var countDown = 0;
            var deferred = defer();
            array_reduce(promises, function (undefined, promise, index) {
                var snapshot;
                if (isPromise(promise) && (snapshot = promise.inspect()).state === 'fulfilled') {
                    promises[index] = snapshot.value;
                } else {
                    ++countDown;
                    when(promise, function (value) {
                        promises[index] = value;
                        if (--countDown === 0) {
                            deferred.resolve(promises);
                        }
                    }, deferred.reject, function (progress) {
                        deferred.notify({
                            index: index,
                            value: progress
                        });
                    });
                }
            }, void 0);
            if (countDown === 0) {
                deferred.resolve(promises);
            }
            return deferred.promise;
        });
    }
    Promise.prototype.all = function () {
        return all(this);
    };
    Q.allResolved = deprecate(allResolved, 'allResolved', 'allSettled');
    function allResolved(promises) {
        return when(promises, function (promises) {
            promises = array_map(promises, Q);
            return when(all(array_map(promises, function (promise) {
                return when(promise, noop, noop);
            })), function () {
                return promises;
            });
        });
    }
    Promise.prototype.allResolved = function () {
        return allResolved(this);
    };
    Q.allSettled = allSettled;
    function allSettled(promises) {
        return Q(promises).allSettled();
    }
    Promise.prototype.allSettled = function () {
        return this.then(function (promises) {
            return all(array_map(promises, function (promise) {
                promise = Q(promise);
                function regardless() {
                    return promise.inspect();
                }
                return promise.then(regardless, regardless);
            }));
        });
    };
    Q.fail = Q['catch'] = function (object, rejected) {
        return Q(object).then(void 0, rejected);
    };
    Promise.prototype.fail = Promise.prototype['catch'] = function (rejected) {
        return this.then(void 0, rejected);
    };
    Q.progress = progress;
    function progress(object, progressed) {
        return Q(object).then(void 0, void 0, progressed);
    }
    Promise.prototype.progress = function (progressed) {
        return this.then(void 0, void 0, progressed);
    };
    Q.fin = Q['finally'] = function (object, callback) {
        return Q(object)['finally'](callback);
    };
    Promise.prototype.fin = Promise.prototype['finally'] = function (callback) {
        callback = Q(callback);
        return this.then(function (value) {
            return callback.fcall().then(function () {
                return value;
            });
        }, function (reason) {
            return callback.fcall().then(function () {
                throw reason;
            });
        });
    };
    Q.done = function (object, fulfilled, rejected, progress) {
        return Q(object).done(fulfilled, rejected, progress);
    };
    Promise.prototype.done = function (fulfilled, rejected, progress) {
        var onUnhandledError = function (error) {
            nextTick(function () {
                makeStackTraceLong(error, promise);
                if (Q.onerror) {
                    Q.onerror(error);
                } else {
                    throw error;
                }
            });
        };
        var promise = fulfilled || rejected || progress ? this.then(fulfilled, rejected, progress) : this;
        if (typeof process === 'object' && process && process.domain) {
            onUnhandledError = process.domain.bind(onUnhandledError);
        }
        promise.then(void 0, onUnhandledError);
    };
    Q.timeout = function (object, ms, message) {
        return Q(object).timeout(ms, message);
    };
    Promise.prototype.timeout = function (ms, message) {
        var deferred = defer();
        var timeoutId = setTimeout(function () {
                deferred.reject(new Error(message || 'Timed out after ' + ms + ' ms'));
            }, ms);
        this.then(function (value) {
            clearTimeout(timeoutId);
            deferred.resolve(value);
        }, function (exception) {
            clearTimeout(timeoutId);
            deferred.reject(exception);
        }, deferred.notify);
        return deferred.promise;
    };
    Q.delay = function (object, timeout) {
        if (timeout === void 0) {
            timeout = object;
            object = void 0;
        }
        return Q(object).delay(timeout);
    };
    Promise.prototype.delay = function (timeout) {
        return this.then(function (value) {
            var deferred = defer();
            setTimeout(function () {
                deferred.resolve(value);
            }, timeout);
            return deferred.promise;
        });
    };
    Q.nfapply = function (callback, args) {
        return Q(callback).nfapply(args);
    };
    Promise.prototype.nfapply = function (args) {
        var deferred = defer();
        var nodeArgs = array_slice(args);
        nodeArgs.push(deferred.makeNodeResolver());
        this.fapply(nodeArgs).fail(deferred.reject);
        return deferred.promise;
    };
    Q.nfcall = function (callback) {
        var args = array_slice(arguments, 1);
        return Q(callback).nfapply(args);
    };
    Promise.prototype.nfcall = function () {
        var nodeArgs = array_slice(arguments);
        var deferred = defer();
        nodeArgs.push(deferred.makeNodeResolver());
        this.fapply(nodeArgs).fail(deferred.reject);
        return deferred.promise;
    };
    Q.nfbind = Q.denodeify = function (callback) {
        var baseArgs = array_slice(arguments, 1);
        return function () {
            var nodeArgs = baseArgs.concat(array_slice(arguments));
            var deferred = defer();
            nodeArgs.push(deferred.makeNodeResolver());
            Q(callback).fapply(nodeArgs).fail(deferred.reject);
            return deferred.promise;
        };
    };
    Promise.prototype.nfbind = Promise.prototype.denodeify = function () {
        var args = array_slice(arguments);
        args.unshift(this);
        return Q.denodeify.apply(void 0, args);
    };
    Q.nbind = function (callback, thisp) {
        var baseArgs = array_slice(arguments, 2);
        return function () {
            var nodeArgs = baseArgs.concat(array_slice(arguments));
            var deferred = defer();
            nodeArgs.push(deferred.makeNodeResolver());
            function bound() {
                return callback.apply(thisp, arguments);
            }
            Q(bound).fapply(nodeArgs).fail(deferred.reject);
            return deferred.promise;
        };
    };
    Promise.prototype.nbind = function () {
        var args = array_slice(arguments, 0);
        args.unshift(this);
        return Q.nbind.apply(void 0, args);
    };
    Q.nmapply = Q.npost = function (object, name, args) {
        return Q(object).npost(name, args);
    };
    Promise.prototype.nmapply = Promise.prototype.npost = function (name, args) {
        var nodeArgs = array_slice(args || []);
        var deferred = defer();
        nodeArgs.push(deferred.makeNodeResolver());
        this.dispatch('post', [
            name,
            nodeArgs
        ]).fail(deferred.reject);
        return deferred.promise;
    };
    Q.nsend = Q.nmcall = Q.ninvoke = function (object, name) {
        var nodeArgs = array_slice(arguments, 2);
        var deferred = defer();
        nodeArgs.push(deferred.makeNodeResolver());
        Q(object).dispatch('post', [
            name,
            nodeArgs
        ]).fail(deferred.reject);
        return deferred.promise;
    };
    Promise.prototype.nsend = Promise.prototype.nmcall = Promise.prototype.ninvoke = function (name) {
        var nodeArgs = array_slice(arguments, 1);
        var deferred = defer();
        nodeArgs.push(deferred.makeNodeResolver());
        this.dispatch('post', [
            name,
            nodeArgs
        ]).fail(deferred.reject);
        return deferred.promise;
    };
    Q.nodeify = nodeify;
    function nodeify(object, nodeback) {
        return Q(object).nodeify(nodeback);
    }
    Promise.prototype.nodeify = function (nodeback) {
        if (nodeback) {
            this.then(function (value) {
                nextTick(function () {
                    nodeback(null, value);
                });
            }, function (error) {
                nextTick(function () {
                    nodeback(error);
                });
            });
        } else {
            return this;
        }
    };
    var qEndingLine = captureLine();
    return Q;
});

define('common/lib/utils', [
    'require',
    'exports'
], function (require, exports) {
    exports.redirect = function (url, convert, from) {
        var a = document.createElement('a');
        convert = !!convert;
        a.href = url;
        var qs = 'u=' + encodeURIComponent(a.href);
        if (convert) {
            qs += '&c=1';
        }
        if (from) {
            qs += '&fr=' + from;
        }
        return '/api/proxy/redirect?' + qs;
    };
    exports.imagesLoaded = function (imgs, callback) {
        var len = imgs.length;
        var tags = [];
        for (var i = 0; i < len; i++) {
            tags[i] = false;
        }
        imgs.forEach(function (img, index) {
            img.onload = function () {
                tags[index] = true;
            };
            img.onerror = function () {
                tags[index] = true;
            };
        });
        var interval = setInterval(function () {
                var tag = true;
                tags.forEach(function (value, index) {
                    if (value === false) {
                        tag = false;
                    }
                });
                if (tag === true) {
                    clearInterval(interval);
                    callback(imgs);
                }
            }, 100);
    };
    exports.throttle = function (callbackList, interval) {
        var previous = 0;
        var timerList = [];
        function isTimer() {
            if (!timerList.length) {
                return false;
            }
            return timerList.some(function (element) {
                if (element) {
                    return true;
                }
            });
        }
        return function () {
            var now = new Date().getTime();
            if (!previous) {
                previous = now;
            }
            var remaining = interval - now + previous;
            if (remaining <= 0) {
                if (isTimer()) {
                    timerList.forEach(function (value) {
                        clearTimeout(value);
                    });
                    timerList = [];
                }
                previous = now;
            }
            if (remaining > 0 && !timerList.length) {
                callbackList.forEach(function (value) {
                    timerList.push(setTimeout(value, remaining));
                });
            }
        };
    };
    exports.extend = function (target, source) {
        for (var key in source) {
            if (source.hasOwnProperty(key)) {
                if (target[key] && exports.isArray(target[key])) {
                    target[key] = target[key].concat(source[key]);
                } else if (target[key] && exports.isObject(target[key])) {
                    target[key] = exports.extend(target[key], source[key]);
                } else {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    exports.isArray = function (arr) {
        return Object.prototype.toString.call(arr) === '[object Array]';
    };
    exports.isObject = function (obj) {
        return Object.prototype.toString.call(obj) === '[object Object]';
    };
    exports.getMin = function (arr) {
        var minIndex = 0;
        var minHeight = Number.POSITIVE_INFINITY;
        for (var i = 0, len = arr.length; i < len; i++) {
            if (arr[i] < minHeight) {
                minIndex = i;
                minHeight = arr[i];
            }
        }
        return {
            minIndex: minIndex,
            minHeight: minHeight
        };
    };
    exports.getMax = function (arr) {
        var maxIndex = 0;
        var maxHeight = Number.NEGATIVE_INFINITY;
        for (var i = 0, len = arr.length; i < len; i++) {
            if (arr[i] > maxHeight) {
                maxIndex = i;
                maxHeight = arr[i];
            }
        }
        return {
            maxIndex: maxIndex,
            maxHeight: maxHeight
        };
    };
    return exports;
});

define('common/ui/viewport', [
    'require',
    'zepto'
], function (require) {
    var $ = require('zepto');
    var viewport = {};
    var $win = $(window);
    var $doc = $(document);
    var bottomFns = [];
    var rotateFns = [];
    viewport.init = function () {
        $win.on('scroll.viewport', function () {
            if ($win.scrollTop() + $win.height() > $doc.height()) {
                for (var i = 0; i < bottomFns.length; i++) {
                    var disFn = bottomFns[i];
                    disFn.call(null);
                }
            }
        });
        $win.on('orientationchange.viewport', function (e) {
            for (var i = 0; i < rotateFns.length; i++) {
                var rotateFn = rotateFns[i];
                rotateFn.call(null);
            }
        });
    };
    viewport.onArrivalBottom = function (fn) {
        bottomFns.push(fn);
    };
    viewport.onWindowRotate = function (fn) {
        rotateFns.push(fn);
    };
    return viewport;
});

define('common/widget/iframeOb', [
    'require',
    'common/lib/q',
    'common/lib/env'
], function (require) {
    var Q = require('common/lib/q');
    var env = require('common/lib/env');
    var watchMessage = true;
    window.addEventListener('popstate', function () {
        var s = document.getElementsByTagName('iframe');
        for (var i = 0, n = s.length; i < n; i++) {
            s[i].width = window.innerWidth - 10;
            s[i].style.width = window.innerWidth - 10 + 'px';
        }
        setTimeout(function () {
            for (var i = 0, n = s.length; i < n; i++) {
                s[i].width = window.innerWidth;
                s[i].style.width = window.innerWidth + 'px';
            }
        }, 100);
    });
    var _message = function (win, action, data) {
        var msg = {
                action: action,
                data: data || {}
            };
        win.postMessage(JSON.stringify(msg), '*');
    };
    var Ob = function (options) {
        var self = this;
        self._moreFn = [];
        self._iframeSet = {};
        self._action = {
            _ready: function (data, source) {
                _message(source, '_whoRU', {
                    id: 'Hello',
                    name: 'LiLei'
                });
            },
            _ensure: function (data, source, iframe) {
                if (data.name === 'HanMeimei' && data.id === 'Hello') {
                    _message(source, '_options', options);
                }
            },
            changeHeight: function (data, source, iframe, deferred) {
                if (data.height) {
                    iframe.height = data.height;
                    iframe.style.height = data.height + 'px';
                    iframe.style.width = window.innerWidth + 'px';
                    iframe.style.position = 'static';
                    setTimeout(function () {
                        deferred.resolve();
                    }, 0);
                }
            },
            more: function (data) {
                for (var i = 0, n = self._moreFn.length; i < n; i++) {
                    self._moreFn[i].call(null, data.more);
                }
            }
        };
        window.addEventListener('message', function (ev) {
            if (watchMessage) {
                var targetObj = self._getTargetFrame(ev.source);
                if (!targetObj) {
                    return;
                }
                var targetIFrame = targetObj.el;
                var targetDefer = targetObj.defer;
                var data;
                try {
                    data = JSON.parse(ev.data);
                } catch (e) {
                    self._message(ev.source, 'unknown', {});
                    return;
                }
                if (data.action === 'unknown') {
                    throw new Error('child response unknown method');
                }
                var act = 'unknown';
                if (self._action[data.action]) {
                    act = data.action;
                }
                if (act === 'unknown') {
                    _message(ev.source, act, {});
                    return;
                }
                try {
                    self._action[act].call(self, data.data || {}, ev.source, targetIFrame, targetDefer);
                } catch (e) {
                    _message(ev.source, 'error', {});
                }
            }
        });
    };
    Ob.prototype._getTargetFrame = function (source) {
        var self = this;
        var frameSet = self._iframeSet;
        for (var i in frameSet) {
            if (!frameSet.hasOwnProperty(i)) {
                continue;
            }
            if (frameSet[i].el.contentWindow === source) {
                return frameSet[i];
            }
        }
        return false;
    };
    Ob.prototype.createIFrame = function (url) {
        var self = this;
        var iframe = document.createElement('iframe');
        var deferred = Q.defer();
        iframe.id = env.guid('wise');
        iframe.className = 'wise-iframe';
        iframe.height = 0;
        iframe.scrolling = 'no';
        iframe.src = url;
        iframe.style.cssText = '' + 'margin: -5px 0; ' + 'padding: 0; ' + 'border: 0;' + 'width: ' + window.innerWidth + 'px; ' + 'height: 0; ' + 'position: absolute;';
        var obj = {
                el: iframe,
                defer: deferred
            };
        self._iframeSet[iframe.id] = obj;
        return obj;
    };
    Ob.prototype.onMore = function (fn) {
        if (typeof fn === 'function') {
            this._moreFn.push(fn);
        }
    };
    return Ob;
});

define('common/ui/wise', [
    'require',
    'common/lib/q',
    'common/widget/iframeOb'
], function (require) {
    var Q = require('common/lib/q');
    var Ob = require('common/widget/iframeOb');
    var Wise = function (selector, options) {
        var el;
        var self = this;
        if (selector instanceof Element) {
            el = selector;
        } else {
            el = document.querySelector(selector);
        }
        if (!el) {
            throw new Error('element is not exist');
        }
        self.el = el;
        self._more = false;
        options = options || {};
        var ob = new Ob(options);
        ob.onMore(function (more) {
            self._more = !!more;
        });
        this.ob = ob;
    };
    Wise.prototype.load = function (keyword, from) {
        this.from = from;
        this.keyword = keyword;
        this.pageNum = 1;
        var deferred = Q.defer();
        deferred.resolve();
        this.loadPromise = deferred.promise;
        this.el.innerHTML = '';
        return this._loadIFrameWithKeywordAndFrom(this.keyword, this.from, this.pageNum);
    };
    Wise.prototype.more = function () {
        var self = this;
        if (!self._more) {
            var deferred = Q.defer();
            deferred.reject('no more');
            return deferred.promise;
        }
        self.pageNum += 1;
        return self._loadIFrameWithKeywordAndFrom(self.keyword, self.from, self.pageNum);
    };
    Wise.prototype._loadIFrameWithKeywordAndFrom = function (keyword, from, pageNum) {
        var self = this;
        var deferred = Q.defer();
        this.loadPromise.then(function () {
            pageNum = parseInt(pageNum, 10) || 1;
            if (pageNum < 1) {
                pageNum = 1;
            }
            var url = '/api/proxy/search' + '?word=' + encodeURIComponent(keyword) + '&fr=' + encodeURIComponent(from) + '&pn=' + pageNum;
            var target = self.ob.createIFrame(url);
            var iframe = target.el;
            target.defer.promise.then(function () {
                deferred.resolve();
            }).fail(function () {
                deferred.reject();
            });
            self.el.appendChild(iframe);
        });
        self.loadPromise = deferred.promise;
        return deferred.promise;
    };
    return Wise;
});

define('common/master', ['require'], function (require) {
    var exports = {};
    function initTongji() {
    }
    exports.start = function () {
        initTongji();
    };
    return exports;
});