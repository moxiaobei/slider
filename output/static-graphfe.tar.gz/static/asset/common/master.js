/*! 2015 Baidu Inc. All Rights Reserved */
define("common/master",["require"],function(require){function e(){}var exports={};return exports.start=function(){e()},exports});