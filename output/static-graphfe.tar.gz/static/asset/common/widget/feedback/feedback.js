/*! 2015 Baidu Inc. All Rights Reserved */
define('common/widget/feedback/feedback', [
    'require',
    'exports',
    'common/lib/env',
    'openjs'
], function (require, exports) {
    var env = require('common/lib/env');
    var Box = require('openjs');
    var feedback = document.querySelector('.feedback-a');
    exports.init = function () {
        if (feedback) {
            var url = 'http://ufosdk.baidu.com/' + '?m=Client' + '&a=postView' + '&appid=284' + '&needEmail=false' + '&webURL=' + encodeURIComponent(window.location.href) + '&placeholder=' + encodeURIComponent('\u8BF7\u8F93\u5165\u60A8\u7684\u95EE\u9898\u6216\u5EFA\u8BAE') + '&ajax=0';
            feedback.setAttribute('href', url);
            env.ready(function () {
                if (Box.os.ios && Box.version_compare(Box.version, '6.2') >= 0) {
                    feedback.addEventListener('click', function (ev) {
                        Box.ios.invokeApp('utilsfeedback', {
                            params: encodeURIComponent(JSON.stringify({
                                source: 'image',
                                refer: window.top.location.href
                            })),
                            minver: encodeURIComponent('6.2.0.0')
                        });
                        ev.preventDefault();
                    });
                }
            });
        }
    };
    return exports;
});