/*! 2015 Baidu Inc. All Rights Reserved */
define('common/widget/backtop/backtop', [
    'require',
    'zepto'
], function (require) {
    var zepto = require('zepto');
    var backtop = {
        idName: 'backtop',
        show: function () {
            $('#' + this.idName).show();
        },
        hide: function () {
            $('#' + this.idName).hide();
        }
    };
    return backtop;
});