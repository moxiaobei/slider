/*! 2015 Baidu Inc. All Rights Reserved */
define('common/widget/in-view', [
    'require',
    'common/lib/animationFrame',
    'zepto'
], function (require) {
    var selector = '[data-in-view]';
    var raf = require('common/lib/animationFrame').requestAnimationFrame;
    var $ = require('zepto');
    var statStep = 1000;
    var exports = function () {
        var lastTime = 0;
        raf(function (time) {
            lastTime = time;
            requestNextLog(time);
        });
        function requestNextLog(time) {
            if (time - lastTime > statStep) {
                lastTime = time;
                var inV = document.querySelectorAll(selector);
                if (inV.length > 0) {
                    var nl = checkInView(inV);
                    var ll = collectStInfo(nl);
                    sendLog(ll);
                }
            }
            raf(requestNextLog);
        }
        function checkInView(nodeList) {
            var inViewList = [];
            var h = window.innerHeight;
            for (var i = 0, n = nodeList.length; i < n; i++) {
                var el = nodeList[i];
                if (el.getBoundingClientRect) {
                    var rect = el.getBoundingClientRect();
                    if (rect.top >= 0 && rect.top < h) {
                        inViewList.push(el);
                    } else if (inViewList.length > 0) {
                        break;
                    }
                }
            }
            return inViewList;
        }
        function collectStInfo(nodeList) {
            var logList = [];
            for (var i = 0, n = nodeList.length; i < n; i++) {
                var el = nodeList[i];
                var s = $(el).attr('data-in-view');
                el.removeAttribute('data-in-view');
                if (s) {
                    logList.push(s);
                }
            }
            return logList;
        }
        function sendLog(logList) {
            if (logList.length === 0) {
                return;
            }
            var img = document.createElement('img');
            var path = '/api/log/?';
            path += 'a=inview';
            path += '&i=' + encodeURIComponent(logList.join('|'));
            img.src = path;
        }
    };
    return exports;
});