/*! 2015 Baidu Inc. All Rights Reserved */
define('common/widget/toast/toast', [
    'require',
    'exports',
    'zepto'
], function (require, exports) {
    var $ = require('zepto');
    var win = window.top;
    var doc = $(win.document);
    var toast = {
            html: '<div class="toast-ld"><span class="toast-ld-pic"></span><span>\u6B63\u5728\u52A0\u8F7D...</span></div>',
            makeText: function (msg, duration) {
                var that = this;
                var tmpl = this.el.html();
                duration = duration || 2000;
                this.el.html(msg);
                this.el.addClass('toast-ld-show toast-ld-txt');
                this.el.css('margin-left', doc.find('.toast-ld').width() / -2 + 'px');
                setTimeout(function () {
                    that.el.removeClass('toast-ld-show toast-ld-txt');
                    that.el.attr('style', '');
                    that.el.html(tmpl);
                }, duration);
            },
            show: function (duration) {
                this.el.addClass('toast-ld-show');
                if (duration) {
                    this.hide(duration);
                }
            },
            hide: function (duration) {
                var that = this;
                duration = duration || 300;
                setTimeout(function () {
                    that.el.removeClass('toast-ld-show');
                }, duration);
            },
            setGravity: function (pos) {
            },
            initialize: function () {
                this.el = $(this.html);
                this.el.appendTo(doc.find('body'));
            }
        };
    toast.initialize();
    return toast;
});