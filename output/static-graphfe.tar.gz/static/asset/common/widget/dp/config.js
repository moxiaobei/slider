/*! 2015 Baidu Inc. All Rights Reserved */
window.alogObjectConfig = {
    product: '666',
    page: '666_1',
    speed: { sample: '0.3' },
    monkey: { sample: '0.3' },
    exception: { sample: '0.3' },
    feature: { sample: '0.3' }
};
void function (e, t, n, a, r, o) {
    function c(t) {
        e.attachEvent ? e.attachEvent('onload', t, !1) : e.addEventListener && e.addEventListener('load', t);
    }
    function i(e, n, a) {
        a = a || 15;
        var r = new Date();
        r.setTime(new Date().getTime() + 1000 * a), t.cookie = e + '=' + escape(n) + ';path=/;expires=' + r.toGMTString();
    }
    function s(e) {
        var n = t.cookie.match(new RegExp('(^| )' + e + '=([^;]*)(;|$)'));
        return null != n ? unescape(n[2]) : null;
    }
    function d() {
        var e = s('PMS_JT');
        if (e) {
            i('PMS_JT', '', -1);
            try {
                e = eval(e);
            } catch (n) {
                e = {};
            }
            e.r && t.referrer.replace(/#.*/, '') != e.r || alog('speed.set', 'wt', e.s);
        }
    }
    c(function () {
        alog('speed.set', 'lt', +new Date()), r = t.createElement(n), r.async = !0, r.src = a + '?v=' + ~(new Date() / 86400000), o = t.getElementsByTagName(n)[0], o.parentNode.insertBefore(r, o);
    }), d();
}(window, document, 'script', 'http://img.baidu.com/hunter/alog/dp.mobile.min.js');