/*! 2015 Baidu Inc. All Rights Reserved */
/**
 * @file dp前端性能分析代码－统计白屏时间
 *       pc和mobile端会稍有不同，必须严格按照该文档来部署
 * @author wukaifang(wukaifang@baidu.com)
 */
 /*eslint-disable*/
alog('speed.set', 'ht', +new Date);
