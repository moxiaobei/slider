/*! 2015 Baidu Inc. All Rights Reserved */
alog('speed.set', 'ht', +new Date());