/*! 2015 Baidu Inc. All Rights Reserved */
define('common/widget/iframeOb', [
    'require',
    'common/lib/q',
    'common/lib/env'
], function (require) {
    var Q = require('common/lib/q');
    var env = require('common/lib/env');
    var watchMessage = true;
    window.addEventListener('popstate', function () {
        var s = document.getElementsByTagName('iframe');
        for (var i = 0, n = s.length; i < n; i++) {
            s[i].width = window.innerWidth - 10;
            s[i].style.width = window.innerWidth - 10 + 'px';
        }
        setTimeout(function () {
            for (var i = 0, n = s.length; i < n; i++) {
                s[i].width = window.innerWidth;
                s[i].style.width = window.innerWidth + 'px';
            }
        }, 100);
    });
    var _message = function (win, action, data) {
        var msg = {
                action: action,
                data: data || {}
            };
        win.postMessage(JSON.stringify(msg), '*');
    };
    var Ob = function (options) {
        var self = this;
        self._moreFn = [];
        self._iframeSet = {};
        self._action = {
            _ready: function (data, source) {
                _message(source, '_whoRU', {
                    id: 'Hello',
                    name: 'LiLei'
                });
            },
            _ensure: function (data, source, iframe) {
                if (data.name === 'HanMeimei' && data.id === 'Hello') {
                    _message(source, '_options', options);
                }
            },
            changeHeight: function (data, source, iframe, deferred) {
                if (data.height) {
                    iframe.height = data.height;
                    iframe.style.height = data.height + 'px';
                    iframe.style.width = window.innerWidth + 'px';
                    iframe.style.position = 'static';
                    setTimeout(function () {
                        deferred.resolve();
                    }, 0);
                }
            },
            more: function (data) {
                for (var i = 0, n = self._moreFn.length; i < n; i++) {
                    self._moreFn[i].call(null, data.more);
                }
            }
        };
        window.addEventListener('message', function (ev) {
            if (watchMessage) {
                var targetObj = self._getTargetFrame(ev.source);
                if (!targetObj) {
                    return;
                }
                var targetIFrame = targetObj.el;
                var targetDefer = targetObj.defer;
                var data;
                try {
                    data = JSON.parse(ev.data);
                } catch (e) {
                    self._message(ev.source, 'unknown', {});
                    return;
                }
                if (data.action === 'unknown') {
                    throw new Error('child response unknown method');
                }
                var act = 'unknown';
                if (self._action[data.action]) {
                    act = data.action;
                }
                if (act === 'unknown') {
                    _message(ev.source, act, {});
                    return;
                }
                try {
                    self._action[act].call(self, data.data || {}, ev.source, targetIFrame, targetDefer);
                } catch (e) {
                    _message(ev.source, 'error', {});
                }
            }
        });
    };
    Ob.prototype._getTargetFrame = function (source) {
        var self = this;
        var frameSet = self._iframeSet;
        for (var i in frameSet) {
            if (!frameSet.hasOwnProperty(i)) {
                continue;
            }
            if (frameSet[i].el.contentWindow === source) {
                return frameSet[i];
            }
        }
        return false;
    };
    Ob.prototype.createIFrame = function (url) {
        var self = this;
        var iframe = document.createElement('iframe');
        var deferred = Q.defer();
        iframe.id = env.guid('wise');
        iframe.className = 'wise-iframe';
        iframe.height = 0;
        iframe.scrolling = 'no';
        iframe.src = url;
        iframe.style.cssText = '' + 'margin: -5px 0; ' + 'padding: 0; ' + 'border: 0;' + 'width: ' + window.innerWidth + 'px; ' + 'height: 0; ' + 'position: absolute;';
        var obj = {
                el: iframe,
                defer: deferred
            };
        self._iframeSet[iframe.id] = obj;
        return obj;
    };
    Ob.prototype.onMore = function (fn) {
        if (typeof fn === 'function') {
            this._moreFn.push(fn);
        }
    };
    return Ob;
});