/*! 2015 Baidu Inc. All Rights Reserved */
define("common/widget/camera",["require"],function(require){var exports={};return exports.start=function(){},exports});